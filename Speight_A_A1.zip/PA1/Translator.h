// Translator.h - Handles translation of words and sentences using the Model class

#ifndef TRANSLATOR_H
#define TRANSLATOR_H

#include <string> // Ensure std::string is available

class Model; // Forward declaration of Model class

class Translator {
    public:
        Translator();  // Constructor
        ~Translator(); // Destructor

        // Translates a single word into Rövarspråket
        std::string translateEnglishWord(std::string word);

        // Translates an entire sentence while preserving spaces and punctuation
        std::string translateEnglishSentence(std::string sentence);

    private:
        Model* model; // Pointer to avoid incomplete type issues
};

#endif