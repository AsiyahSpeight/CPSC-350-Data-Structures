// Model.h - Handles character translation rules for Rövarspråket

#ifndef MODEL_H
#define MODEL_H

#include <string> // Ensure std::string is available

class Model {
    public:
        Model();  // A default constructor
        ~Model(); // A default destructor

        // Translates a single consonant according to Rövarspråket rules
        std::string translateSingleConsonant(char c);

        // Translates a single vowel (remains unchanged)
        std::string translateSingleVowel(char c);
};

#endif