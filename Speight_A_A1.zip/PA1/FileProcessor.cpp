// FileProcessor.cpp - Handles file input and output for translation

#include "FileProcessor.h"
#include <iostream>
#include <fstream>

// A default constructor
FileProcessor::FileProcessor() {}

// A default destructor
FileProcessor::~FileProcessor() {}

// processFile – takes a string representing the input file (English) 
// and a string representing the output file (where the Rövarspråket translation will be written). 
// This method has a void return type. 
// The method should produce an HTML file that has the original English text in bold 
// followed by an empty line, followed by the Rövarspråket translation in italics.
void FileProcessor::processFile(std::string inputFile, std::string outputFile) {
    std::ifstream inFile(inputFile);  // Open input file
    std::ofstream outFile(outputFile); // Open output file

    // Validate file opening
    if (!inFile || !outFile) {
        std::cerr << "Error opening files!" << std::endl;
        return;
    }

    Translator translator; // Instantiate Translator
    std::string line;

    // Start HTML structure
    outFile << "<!DOCTYPE html>\n";
    outFile << "<html>\n<head>\n<title>English to Robber Translation</title>\n</head>\n<body>\n";

    // Read input file line by line
    while (getline(inFile, line)) {
        // Write original text in bold inside a paragraph
        outFile << "<p><b>" << line << "</b><br></p>\n";

        // Write translated text in italics inside a paragraph
        outFile << "<p><i>" << translator.translateEnglishSentence(line) << "</i><br></p>\n";
    }

    // Close HTML structure
    outFile << "</body>\n</html>\n";

    // Close file streams
    inFile.close();
    outFile.close();
}