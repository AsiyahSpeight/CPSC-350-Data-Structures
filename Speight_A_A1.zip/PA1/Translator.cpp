// Translator.cpp - Implements translation of words and sentences using the Model class

#include "Translator.h"
#include "Model.h"
#include <sstream>  // For breaking sentences into words
#include <cctype>   // For checking punctuation
#include <iostream> // For debugging (if needed)
#include <string>   // For string manipulation

// A default constructor
Translator::Translator() {
    model = new Model(); // dynamically allocate model
}

// A default destructor
Translator::~Translator() {
    delete model;
}

// translateEnglishWord – takes a single English word and returns its Rövarspråket translation.
std::string Translator::translateEnglishWord(std::string word) {
    std::string translatedWord = ""; // Store the translated word
    std::string vowels = "AEIOUaeiou"; // Define vowels

    for (char c : word) {
        if (vowels.find(c) != std::string::npos) { // If the character is a vowel
            translatedWord += model->translateSingleVowel(c);
        } else { // If the character is a consonant
            translatedWord += model->translateSingleConsonant(c);
        }
    }

    return translatedWord; // Return the translated word
}

// translateEnglishSentence – takes an English sentence and returns its Rövarspråket translation.
// LLM ChatGPT helped refine punctuation handling and ensure word-by-word translation is correct.
std::string Translator::translateEnglishSentence(std::string sentence) {
    std::stringstream ss(sentence); // String stream to split words
    std::string word, translatedSentence = "";

    // Read each word from the sentence
    while (ss >> word) {
        std::string translatedWord = translateEnglishWord(word); // Translate the word

        // LLM ChatGPT FIX: Ensured punctuation at the end of words is properly preserved.
        // Previous implementation incorrectly removed the last character regardless of whether it was punctuation.
        char lastChar = word.back();
        if (ispunct(lastChar)) {  
            // If the last character is punctuation, keep it at the end of the translated word
            std::string wordWithoutPunctuation = word.substr(0, word.size() - 1); // Remove last char
            translatedWord = translateEnglishWord(wordWithoutPunctuation) + lastChar; // Append punctuation back
        }

        translatedSentence += translatedWord + " "; // Append translated word with a space
    }

    // LLM ChatGPT FIX: Previously, an extra space remained at the end of the sentence.
    // This removes the trailing space before returning the final translated sentence.
    if (!translatedSentence.empty()) {
        translatedSentence.pop_back();
    }

    return translatedSentence; // Return the translated sentence
}