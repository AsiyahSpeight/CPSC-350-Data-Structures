AUTHOR INFO
Full name: Asiyah Speight  
Student ID: 2357167  
Chapman Email: aspeight@chapman.edu  
Course number and section: CPSC-350-04  
Assignment or exercise number: PA1: Robber Language Translator  

---

ERRORS  
There are no known compile-time or runtime errors in the current implementation.  
However, some edge cases may affect translation accuracy:  
- The program assumes **standard English punctuation** and spaces.  
- Special characters such as **emojis** are not handled explicitly.  
- Some punctuation placement in the output file may require manual review.  

---

SOURCES  
A list of all references used to complete the assignment:  
- **LLM ChatGPT Assistance**:  
  - Helped troubleshoot **circular dependencies** between `Model`, `Translator`, and `FileProcessor`.  
  - Debugged segmentation faults and **pointer management issues**.  
  - Assisted in refining **function documentation** and **handling punctuation properly** in `translateEnglishSentence()`.  

- **Course zyBooks**:  
  - Used **Chapter 22 (Objects and Classes)** for class structure and implementation.  
  - Referenced **Chapter 24 (File I/O, String Streams)** for reading and writing files.  

- **Stack Overflow**:  
  - Used for debugging and confirming **C++ syntax** regarding `std::stringstream`.  
  - Searched for best practices in **dynamic memory allocation (`new` and `delete`)**.  

- **C++ Documentation**:  
  - [https://cplusplus.com/](https://cplusplus.com/)  
  - [https://www.cplusplus.com/reference/string/string/](https://www.cplusplus.com/reference/string/string/)  

---

RUNNING INSTRUCTIONS  
To **compile the program**, run:  
```sh
g++ *.cpp -o A1.exe

To **execute the program**, run:
./A1.exe inputfile.txt outputfile.html

- Replace inputfile.txt with the English text file to be translated.
- Replace outputfile.html with the desired output file name.

The program will generate an HTML file where:
- The original English text appears in bold.
- The translated Rövarspråket text appears in italics.
