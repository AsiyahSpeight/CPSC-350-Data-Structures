// Model.cpp - Implements the translation rules for Rövarspråket

#include "Model.h"
#include <cctype>  // For character classification

// A default constructor
Model::Model() {}

// A default destructor
Model::~Model() {}

// translateSingleConsonant – takes a single consonant character as input 
// and returns a string representing its encoding in Rövarspråket. 
// Capitalization should be preserved.
std::string Model::translateSingleConsonant(char c) {
    std::string vowels = "AEIOUaeiou"; // Define vowels
    if (!isalpha(c) || vowels.find(c) != std::string::npos) {
        return std::string(1, c); // If it's a vowel or non-alphabetic, return unchanged
    }
    
    // Preserve capitalization
    std::string translated = std::string(1, c) + "o" + std::string(1, tolower(c));
    return isupper(c) ? translated : std::string(1, c) + "o" + std::string(1, c);
}

// translateSingleVowel – takes a single vowel character as input 
// and returns a string representing its encoding in Rövarspråket. 
// Capitalization should be preserved.
std::string Model::translateSingleVowel(char c) {
    return std::string(1, c); // Vowels remain unchanged in Rövarspråket
}