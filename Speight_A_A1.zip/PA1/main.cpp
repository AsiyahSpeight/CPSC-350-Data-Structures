// main.cpp - Entry point for the program
// The main method should:
// - Take the name of an input file and output file as command-line arguments. 
// - Instantiate a FileProcessor
// - Translate the provided input file to Rövarspråket using the FileProcessor 
// - Write the output to the output file
// - Exit

#include "FileProcessor.h"
#include <iostream>

int main(int argc, char* argv[]) {
    // Ensure correct number of command-line arguments
    if (argc != 3) {
        std::cerr << "Usage: ./A1.exe <inputFile> <outputFile>" << std::endl;
        return 1; // Exit with error
    }

    std::string inputFile = argv[1];  // Get input file name
    std::string outputFile = argv[2]; // Get output file name

    FileProcessor fileProcessor; // Instantiate FileProcessor
    fileProcessor.processFile(inputFile, outputFile); // Process file

    std::cout << "Translation completed! Check the output file: " << outputFile << std::endl;

    return 0; // Successful execution
}