// FileProcessor.h - Handles file input and output operations for translation

#ifndef FILEPROCESSOR_H
#define FILEPROCESSOR_H

#include "Translator.h"
#include <string> // Ensure std::string is available

class FileProcessor {
    public:
        FileProcessor();  // Constructor
        ~FileProcessor(); // Destructor

        // Reads an input text file, translates its content, and writes the output to an HTML file
        void processFile(std::string inputFile, std::string outputFile);
};

#endif